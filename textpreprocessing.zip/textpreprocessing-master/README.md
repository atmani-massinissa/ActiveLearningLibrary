#Introduction

Python package for text preprocessing. Give access to different tools for text cleaning. All the tools have been adapted to be scikit-learn transformers and usable to create
custom pipelines according to our needs.

#Getting Started

1.	cd Text_PreProcessing/
2.	pip install .
3.	Dependencies : numpy, sklearn, pandas, matplotlib, scipy, nltk, wordcloud
4.	API references

#Build and Test
TODO: Describe and show how to build your code and run the tests. 

Go to the test_text_preprocessing file to see example how to use the package.

Transformers:

1)	CleanTransform : clean text and remove non-word-character, underscore, remove one word char, digits except if it's in a word or at the end, multiple spaces and transform
the text in lower case. You can specify characters that you don't want to remove.

2)	StandardizeTransform : remove accent from text.

3)	LemmatizeTransform : english lemmatizer. Example runs, running will be transform in a single word run.

4)	RemoveWordTransform : Take a list of words and remove them from the corpus.

5)	NgramTransform : Transform your text in n_grams words.

#Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://www.visualstudio.com/en-us/docs/git/create-a-readme). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)