import re
import numpy as np
import nltk
from nltk.corpus import wordnet as wn
from nltk import WordNetLemmatizer, pos_tag, ngrams
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.externals.joblib import Parallel, delayed
import unicodedata
from nltk.tokenize import WhitespaceTokenizer
from string import punctuation
from text_preprocessing.util import log_time_usage


# If you setup your environment
# You might want to run download_nltk_resources with the proposed arguments

# TODO: use regex tokenizer instead of word-punct see http://www.nltk.org/_modules/nltk/tokenize/regexp.html

# --- text_preprocessing function --- #

def download_nltk_resources(resources):
    """
    :param resources: ['averaged_perceptron_tagger', 'wordnet', 'punkt']
    :return:
    """
    for resource in resources:
        nltk.download(resource)


def generate_ngrams(words, ngram_min=1, ngram_max=2):
    s = []
    for n in range(ngram_min, ngram_max+1):
        for ngram in ngrams(words, n):
            s.append('--'.join(str(i) for i in ngram))
    return s


def remove_accent(string):
    nfkd_form = unicodedata.normalize('NFKD', string)
    only_ascii = nfkd_form.encode('ASCII', 'ignore').decode('utf-8')
    return only_ascii


def clean_text(string, keep_chars=None):
    """
    :param string: a textual string
    :param keep_chars: list of characters to keep
    :return: string without of the following regex matches
    """

    regex = '|'.join([
        r'[^\s\w]',  # match any non-word-character and non-space
        #r'[0-9]',  # match numbers
        r'_'  # match underscore
    ])

    string = re.sub("-\n", "", string)
    string = re.sub("-", "", string)

    # Extract all format of url in a string
    detect_url_regex = r"\b((?:https?://)?(?:(?:www\.)?(?:[\da-z\.-]+)\.(?:[a-z]{2,6})|(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|(?:(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])))(?::[0-9]{1,4}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])?(?:/[\w\.-]*)*/?)\b"
    # Remove all the url in the string
    string = re.sub(detect_url_regex, "", string)

    keep_chars_regex = ''.join('(?=[^{0}])'.format(char) for char in keep_chars) if keep_chars else ''

    string = re.sub(r'{0}({1})+'.format(keep_chars_regex, regex), ' ', string)
    string = re.sub(r'(^|\s)\w(?=(\Z|\s))', ' ', string)  # remove one word char
    string = re.sub(r'\d+', "", string)
    string = re.sub(r'(^|\s)\w(?=(\Z|\s))', ' ', string)  # remove one word char
    string = re.sub(r'\s{2,}', ' ', string)  # remove multiple spaces
    string = re.sub(r'^\s|\s$', '', string)  # remove first and last space
    string = " ".join([w for w in string.split() if len(w) > 1])
    return string.lower()


def f_lemmatize(token, tag):
    """
     Lemmatization is type of normalization that treats different
     inflected forms of a word as a single unit.
     Example : ("work", "working", "works", "worked", "working" => same lemma: "work")
     """
    tag = {
        'N': wn.NOUN,
        'V': wn.VERB,
        'R': wn.ADV,
        'J': wn.ADJ
    }.get(tag[0], wn.NOUN)

    return WordNetLemmatizer().lemmatize(token, tag)

def sub_word(txt, word_to_sub):
	assert type(word_to_sub) == tuple
	assert type(word_to_sub[0])  == str
	assert type(word_to_sub[1]) == str
	txt = re.sub(" "+word_to_sub[0]+" ", " "+word_to_sub[1]+" ", txt)
	return txt

# --- text_preprocessing pipeline transformer --- #


class FTransform(BaseEstimator, TransformerMixin):
    """
    Base class for function transformation
    -- Parallel processing is longer than the standart processing on small texts and corpus
    -- Start to be more efficient on corpus of more than 1m
    """
    def __init__(self, f_transform, parallel=False, n_jobs=6):
        """
        :param f_transform: transformation function
        :param parallel: if true proceed parallel processing
        :param n_jobs: number of core to use is parallel processing
        """
        super(FTransform).__init__()
        BaseEstimator.__init__(self)
        self.f_transform = f_transform
        self.parallel = parallel
        self.n_jobs = n_jobs

    def iter_f(self, xs):
        return [self.f_transform(x) for x in xs]

    def transform(self, X, *_):
        with log_time_usage('Transform time'):
            if self.parallel:
                # Split X in n chunk and distribute them to parallel processes
                items, chunk = X, self.n_jobs
                chunks = np.array_split(items, chunk) if chunk < len(items) else [items]
                results = Parallel(n_jobs=self.n_jobs, max_nbytes=1e4)(delayed(self.iter_f)(xs) for xs in chunks)
                results = [item for sublist in results for item in sublist]
            else:
                results = self.iter_f(X)
        return results

    def fit(self, *_):
        return self


class StandardizeTransform(FTransform):
    def __init__(self, parallel=False, n_jobs=6):
        FTransform.__init__(self, f_transform=self.standardize, parallel=parallel, n_jobs=n_jobs)

    @staticmethod
    def standardize(string):
        return remove_accent(string).lower()


class CleanTransform(FTransform):
    def __init__(self, keep_char=None, parallel=False, n_jobs=6):
        self.keep_char = keep_char
        self.punctuation = punctuation
        if(self.keep_char != None):
            self.punctuation = ''.join([c for c in self.punctuation if c not in keep_char])
        super(CleanTransform, self).__init__(f_transform=self.clean_text, parallel=parallel, n_jobs=n_jobs)

    def clean_text(self, string):
        return clean_text(string, keep_chars=self.keep_char)

    def clean_text_version2(self, text):
        return clean_text_version2(text, punct=self.punctuation)


class LemmatizeTransform(FTransform):
    def __init__(self, parallel=False, n_jobs=6):
        super(LemmatizeTransform, self).__init__(f_transform=self.lemmatize, parallel=parallel, n_jobs=n_jobs)

    def lemmatize(self, text):
        """Break text into a sentence of lemmatized words.
        Break the document into sentences """
        tokens = [f_lemmatize(token.lower(), tag) for token, tag in pos_tag(WhitespaceTokenizer().tokenize(text))]
        return ' '.join(tokens)


class RemoveWordsTransform(FTransform):
    def __init__(self, non_info_words=None, parallel=False, n_jobs=6):
        FTransform.__init__(self, f_transform=self.remove_words, parallel=parallel, n_jobs=n_jobs)
        self.non_info_words = dict.fromkeys(non_info_words)
    
    def remove_words(self, text):
        text_words = text.split()
        filtered_list = [w for w in text_words if w not in self.non_info_words]
        return ' '.join(filtered_list)


class SubWordsTransform(FTransform):
    def __init__(self, words_to_sub=None, parallel=False, n_jobs=6):
        FTransform.__init__(self, f_transform=self.sub_words, parallel=parallel, n_jobs=n_jobs)
        self.words_to_sub = dict.fromkeys(words_to_sub)

    def sub_words(self, text):
        text = " " + text + " "
        for w in self.words_to_sub:
            text = sub_word(text, w)
        text = text.strip()
        return text

class NgramTransform(FTransform):
    def __init__(self, ngram_max=2, parallel=False, n_jobs=6):
        self.ngram_max = ngram_max
        FTransform.__init__(self, f_transform=self.apply_generate_ngrams, parallel=parallel, n_jobs=n_jobs)

    def apply_generate_ngrams(self, string):
        words = string.split()
        return ' '.join(generate_ngrams(words, ngram_max=self.ngram_max))