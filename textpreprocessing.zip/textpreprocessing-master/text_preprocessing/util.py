from contextlib import contextmanager
import time
import logging


@contextmanager
def log_time_usage(prefix=""):
    '''log the time usage in a code block
    prefix: the prefix text to show
    '''
    logging.basicConfig(level=logging.DEBUG)
    start = time.time()
    try:
        yield
    finally:
        end = time.time()
        elapsed_seconds = float("%.2f" % (end - start))
        #logging.info('%s: elapsed seconds: %s', prefix, elapsed_seconds)