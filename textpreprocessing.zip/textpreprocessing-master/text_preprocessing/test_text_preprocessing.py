from string import punctuation
import unittest
from sklearn.pipeline import Pipeline
from sklearn.base import clone
from text_preprocessing.text_preprocessing import clean_text, remove_accent, clean_text_version2, RemoveWordsTransform, CleanTransform, LemmatizeTransform, StandardizeTransform


class TestRemoveAccent(unittest.TestCase):
    def test_remove_accent(self):
        self.assertEqual(remove_accent("l'été à paris ça rox c#"),
                         "l'ete a paris ca rox c#")


class TestCleanText(unittest.TestCase):

    def test_remove_non_word_char(self):
        self.assertEqual(
            clean_text('hello % word# is | @ ~!@#$%^&*() =+ \ --- my_string'),
            'hello word is my string')

    def test_remove_multiple_space(self):
        self.assertEqual(
            clean_text('     Hello       word     '),
            'hello word')

    def test_remove_number(self):
        self.assertEqual(
            clean_text('Neo4JJ 1995 +33 68'),
            'neo4jj')

    def test_remove_number2(self):
        self.assertEqual(
            clean_text('This must not b3 delet3d, but the number at the end yes 134411'),
            'this must not b3 delet3d but the number at the end yes'
        )

    def test_remove_one_char(self):
        self.assertEqual(
            clean_text('I am a man'),
            'am man')

    def test_remove_underscore(self):
        self.assertEqual(
            clean_text('hello   ____  ___jean_paul'),
            'hello jean paul')

    def test_keep_chars(self):
        self.assertEqual(
            clean_text('C# hello@ #C', keep_chars=['#', '@']),
            'c# hello@ #c')


class TestOtherCleanText(unittest.TestCase):

    def test_other_clean_text(self):
        self.assertEqual(
            clean_text_version2("My name's Momo. I am learnig #C. C# it's a version 2.0 of Java. I love coding and you??? .",
                                ''.join([c for c in punctuation if c not in ['#'] ])),
            'my name momo am learnig #c c# it version of java love coding and you')


class TestProcessingPipe(unittest.TestCase):
    def setUp(self):
        self.corpus = ['hello this is a test' for _ in range(13)]
        keep_char = ['c#', 'it']
        non_info_words = {'hello'} - set(keep_char)

        self.processing = Pipeline([
            ('standardize', StandardizeTransform()),
            ('clean', CleanTransform(keep_char=keep_char)),
            ('lemmatize', LemmatizeTransform()),
            ('stop_word', RemoveWordsTransform(non_info_words=non_info_words))
        ])
        parallel_param = {step + '__parallel': True for step in self.processing.named_steps}
        self.processing_parallel = clone(self.processing).set_params(**parallel_param)

    def test_transform_size(self):
        self.assertEqual(len(self.processing.transform(self.corpus)), len(self.corpus))
        self.assertEqual(len(self.processing_parallel.transform(self.corpus)), len(self.corpus))

if __name__ == '__main__':
    unittest.main()
