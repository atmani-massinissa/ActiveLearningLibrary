from setuptools import setup

setup(name='text_preprocessing',
      version='0.1',
      description='tools for Amaris python applications',
      url='https://tfs.amaris.com/tfs/RandD/RnDTools/_git/Text_PreProcessing',
      author='',
      author_email='',
      license='',
      packages=['text_preprocessing'],
      install_requires=[
         'numpy', 'sklearn', 'pandas', 'matplotlib', 'scipy', 'nltk'
         ],
      zip_safe=False)